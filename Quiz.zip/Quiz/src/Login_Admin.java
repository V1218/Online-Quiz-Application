
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

@SuppressWarnings("serial")
public class Login_Admin extends JFrame implements ActionListener {
    // Components
    private Container container;
    private JLabel userLabel;
    private JLabel passwordLabel;
    private JTextField userTextField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton signupButton; // Added signup button
    private JLabel statusLabel;

    // Constructor
    public Login_Admin() {
        setAlwaysOnTop(true);
        // Frame setup
        setTitle("ADMIN LOGIN FORM");
        setBounds(300, 90, 400, 350); // Increased height for additional button
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        container = getContentPane();
        container.setLayout(null);
        container.setBackground(new Color(60, 63, 65));

        // User label
        userLabel = new JLabel("Username");
        userLabel.setForeground(Color.WHITE);
        userLabel.setFont(new Font("Arial", Font.BOLD, 14));
        userLabel.setBounds(49, 65, 281, 30);
        container.add(userLabel);

        // Password label
        passwordLabel = new JLabel("Password");
        passwordLabel.setForeground(Color.WHITE);
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 14));
        passwordLabel.setBounds(49, 115, 281, 30);
        container.add(passwordLabel);

        // User text field
        userTextField = new JTextField();
        userTextField.setBounds(149, 65, 181, 30);
        userTextField.setBackground(new Color(169, 169, 169));
        userTextField.setForeground(Color.BLACK);
        userTextField.setFont(new Font("Arial", Font.PLAIN, 14));
        container.add(userTextField);

        // Password field
        passwordField = new JPasswordField();
        passwordField.setBounds(149, 115, 181, 30);
        passwordField.setBackground(new Color(169, 169, 169));
        passwordField.setForeground(Color.BLACK);
        passwordField.setFont(new Font("Arial", Font.PLAIN, 14));
        container.add(passwordField);

        // Login button
        loginButton = new JButton("Login");
        loginButton.setBounds(208, 165, 142, 41);
        loginButton.setBackground(new Color(70, 130, 180));
        loginButton.setForeground(Color.WHITE);
        loginButton.setFont(new Font("Arial", Font.BOLD, 14));
        loginButton.addActionListener(this);
        container.add(loginButton);

        // Signup button
        signupButton = new JButton("Sign Up");
        signupButton.setBounds(40, 165, 142, 41);
        signupButton.setBackground(new Color(34, 139, 34));
        signupButton.setForeground(Color.WHITE);
        signupButton.setFont(new Font("Arial", Font.BOLD, 14));
        signupButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	dispose();
            	SignUp obj =new SignUp();
          	  obj.setVisible(true);
          	 
            }
        });
        container.add(signupButton);

        // Status label
        statusLabel = new JLabel("");
        statusLabel.setBounds(50, 270, 300, 30);
        statusLabel.setForeground(Color.RED);
        container.add(statusLabel);

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        setVisible(true);
    }

    // Action performed method
    @Override
    public void actionPerformed(ActionEvent e) {
        String username = userTextField.getText();
        String password = new String(passwordField.getPassword());

        if (authenticateUser(username, password)) {    
        	dispose();
        	  QuizCreator obj1 =new QuizCreator();
        	  obj1.setVisible(true);
        	 
        	  
          
        } else {
            statusLabel.setText("Invalid username or password");
            statusLabel.setForeground(Color.RED);
        }
    }

    // Method to authenticate user
    private boolean authenticateUser(String username, String password) {
        boolean isValidUser = false;
        String url = "jdbc:mysql://localhost:3306/admindb";
        String dbUsername = "root"; // Replace with your DB username
        String dbPassword = "12345"; // Replace with your DB password

        try {
            Connection con = DriverManager.getConnection(url, dbUsername, dbPassword);
            String sql = "SELECT * FROM adminid WHERE username=? AND password=?";
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setString(1, username);
            statement.setString(2, password);
            ResultSet resultSet = statement.executeQuery();

            isValidUser = resultSet.next();

            resultSet.close();
            statement.close();
            con.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return isValidUser;
    }

    // Main method
    public static void main(String[] args) {
        new Login_Admin();
    }
}
