import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

@SuppressWarnings("serial")
public class QuizCreator extends JFrame implements ActionListener {
    // Components
    private JTextField quizTitleField, organizationField;
    private JTextField questionField, optionAField, optionBField, optionCField, optionDField;
    private JComboBox<String> correctOptionComboBox;
    private JButton saveButton, nextButton, finishButton;
    private JLabel statusLabel;
    private String quizTitle, organization;
    private int questionCount = 0;

    // Constructor
    public QuizCreator() {
        setTitle("Quiz Creator");
        setBounds(300, 90, 600, 550);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        // Initialize components
        quizTitleField = new JTextField(20);
        organizationField = new JTextField(20);
        questionField = new JTextField(20);
        optionAField = new JTextField(20);
        optionBField = new JTextField(20);
        optionCField = new JTextField(20);
        optionDField = new JTextField(20);
        correctOptionComboBox = new JComboBox<>(new String[]{"A", "B", "C", "D"});
        saveButton = new JButton("Save Question");
        nextButton = new JButton("Next Question");
        finishButton = new JButton("Finish Quiz");
        statusLabel = new JLabel();

        // Layout configuration
        gbc.insets = new Insets(10, 10, 10, 10); // Padding around components
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Add components to frame
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(new JLabel("Quiz Title:"), gbc);
        gbc.gridx = 1;
        add(quizTitleField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        add(new JLabel("Organization:"), gbc);
        gbc.gridx = 1;
        add(organizationField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        add(new JLabel("Question:"), gbc);
        gbc.gridx = 1;
        add(questionField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        add(new JLabel("Option A:"), gbc);
        gbc.gridx = 1;
        add(optionAField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        add(new JLabel("Option B:"), gbc);
        gbc.gridx = 1;
        add(optionBField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        add(new JLabel("Option C:"), gbc);
        gbc.gridx = 1;
        add(optionCField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 6;
        add(new JLabel("Option D:"), gbc);
        gbc.gridx = 1;
        add(optionDField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 7;
        add(new JLabel("Correct Option:"), gbc);
        gbc.gridx = 1;
        add(correctOptionComboBox, gbc);

        gbc.gridx = 0;
        gbc.gridy = 8;
        add(saveButton, gbc);
        gbc.gridx = 1;
        add(nextButton, gbc);

        gbc.gridx = 2;
        add(finishButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 9;
        gbc.gridwidth = 3;
        add(statusLabel, gbc);

        // Set action listeners
        saveButton.addActionListener(this);
        nextButton.addActionListener(this);
        finishButton.addActionListener(this);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String action = e.getActionCommand();

        if (action.equals("Save Question")) {
            saveQuestion();
        } else if (action.equals("Next Question")) {
            if (saveQuestion()) {
                clearFields();
            }
        } else if (action.equals("Finish Quiz")) {
            if (saveQuestion()) {
                clearFields();
                generateQuizLink();
            }
        }
    }

    private boolean saveQuestion() {
        if (quizTitle == null) {
            quizTitle = quizTitleField.getText();
            organization = organizationField.getText();
            if (quizTitle.isEmpty() || organization.isEmpty()) {
                statusLabel.setText("Please enter quiz title and organization.");
                statusLabel.setForeground(Color.RED);
                return false;
            }
        }

        String question = questionField.getText();
        String optionA = optionAField.getText();
        String optionB = optionBField.getText();
        String optionC = optionCField.getText();
        String optionD = optionDField.getText();
        String correctOption = (String) correctOptionComboBox.getSelectedItem();

        if (question.isEmpty() || optionA.isEmpty() || optionB.isEmpty() || optionC.isEmpty() || optionD.isEmpty()) {
            statusLabel.setText("All fields must be filled out.");
            statusLabel.setForeground(Color.RED);
            return false;
        }

        if (saveQuestionToDatabase(quizTitle, organization, question, optionA, optionB, optionC, optionD, correctOption)) {
            statusLabel.setText("Question " + (++questionCount) + " saved successfully!");
            statusLabel.setForeground(Color.GREEN);
            return true;
        } else {
            statusLabel.setText("Failed to save question.");
            statusLabel.setForeground(Color.RED);
            return false;
        }
    }

    private boolean saveQuestionToDatabase(String quizTitle, String organization, String question, String optionA, String optionB, String optionC, String optionD, String correctOption) {
        boolean isSaved = false;
        String url = "jdbc:mysql://localhost:3306/quizdb";
        String user = "root";
        String password = "12345";  // Replace with your MySQL password

        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            String sql = "INSERT INTO quizzes (quiz_title, organization, question, option_a, option_b, option_c, option_d, correct_option) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, quizTitle);
            stmt.setString(2, organization);
            stmt.setString(3, question);
            stmt.setString(4, optionA);
            stmt.setString(5, optionB);
            stmt.setString(6, optionC);
            stmt.setString(7, optionD);
            stmt.setString(8, correctOption);

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                isSaved = true;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return isSaved;
    }

    private void clearFields() {
        questionField.setText("");
        optionAField.setText("");
        optionBField.setText("");
        optionCField.setText("");
        optionDField.setText("");
        correctOptionComboBox.setSelectedIndex(0);
    }

    private void generateQuizLink() {
        String quizLink = "http://quizsite.com/" + quizTitle.replaceAll(" ", "_").toLowerCase();
        
        // Create a text area to display the link, making it copyable
        JTextArea linkArea = new JTextArea(quizLink);
        linkArea.setEditable(false);
        linkArea.setForeground(Color.BLUE);
        linkArea.setCursor(new Cursor(Cursor.TEXT_CURSOR));

        JOptionPane.showMessageDialog(this, new JScrollPane(linkArea), "Quiz Finished! Copy this link:", JOptionPane.INFORMATION_MESSAGE);

        quizTitle = null;  // Reset for next quiz creation
    }

    public static void main(String[] args) {
        new QuizCreator();
    }
}
