import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("serial")
public class Display_quiz extends JFrame implements ActionListener {
    private CardLayout cardLayout;
    private JPanel mainPanel, linkPanel, quizPanel;
    private JTextField linkField;
    private JButton submitLinkButton, submitQuizButton, nextButton;
    private JLabel statusLabel;
    private JTextArea questionArea, feedbackArea;
    private JRadioButton[] optionButtons;
    private ButtonGroup optionGroup;
    private JTextField nameField, phoneField, emailField, usernameField;
    private List<QuizQuestion> questions;
    private int currentQuestionIndex = 0;
    private int score = 0;
    private String quizTitle;

    // Constructor
    public Display_quiz() {
        setTitle("Quiz Application");
        setBounds(300, 90, 600, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // CardLayout for switching between panels
        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        // Initialize components
        initializeLinkPanel();
        initializeQuizPanel();

        // Add panels to main panel
        mainPanel.add(linkPanel, "LinkPanel");
        mainPanel.add(quizPanel, "QuizPanel");

        // Set main panel as content pane
        setContentPane(mainPanel);
        setVisible(true);
    }

    private void initializeLinkPanel() {
        linkPanel = new JPanel(new GridBagLayout());
        linkPanel.setBackground(new Color(255, 228, 181)); // Light Orange Background

        GridBagConstraints gbc = new GridBagConstraints();

        linkField = new JTextField(20);
        submitLinkButton = new JButton("Submit");
        statusLabel = new JLabel();

        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0;
        gbc.gridy = 0;
        linkPanel.add(new JLabel("Enter Quiz Link:"), gbc);
        gbc.gridx = 1;
        linkPanel.add(linkField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        linkPanel.add(submitLinkButton, gbc);

        gbc.gridy = 2;
        linkPanel.add(statusLabel, gbc);

        submitLinkButton.addActionListener(this);
    }

    private void initializeQuizPanel() {
        quizPanel = new JPanel(new GridBagLayout());
        quizPanel.setBackground(new Color(173, 216, 230)); // Light Blue Background

        GridBagConstraints gbc = new GridBagConstraints();

        questionArea = new JTextArea(5, 40);
        questionArea.setLineWrap(true);
        questionArea.setWrapStyleWord(true);
        questionArea.setEditable(false);
        optionButtons = new JRadioButton[4];
        optionGroup = new ButtonGroup();
        JPanel optionsPanel = new JPanel(new GridLayout(4, 1));
        for (int i = 0; i < 4; i++) {
            optionButtons[i] = new JRadioButton();
            optionGroup.add(optionButtons[i]);
            optionsPanel.add(optionButtons[i]);
        }

        usernameField = new JTextField(20);
        nameField = new JTextField(20);
        phoneField = new JTextField(20);
        emailField = new JTextField(20);
        submitQuizButton = new JButton("Submit Quiz");
        nextButton = new JButton("Next Question");
        feedbackArea = new JTextArea(5, 40);
        feedbackArea.setEditable(false); // Feedback is initially not editable

        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        quizPanel.add(new JLabel("Please enter your information:"), gbc);

        gbc.gridy = 1;
        gbc.gridwidth = 1;
        quizPanel.add(new JLabel("Username:"), gbc);
        gbc.gridx = 1;
        quizPanel.add(usernameField, gbc);

        
        gbc.gridy = 2;
        gbc.gridx = 0;
        quizPanel.add(new JLabel("Name:"), gbc);
        gbc.gridx = 1;
        quizPanel.add(nameField, gbc);

        gbc.gridy = 3;
        gbc.gridx = 0;
        quizPanel.add(new JLabel("Phone:"), gbc);
        gbc.gridx = 1;
        quizPanel.add(phoneField, gbc);

        gbc.gridy = 4;
        gbc.gridx = 0;
        quizPanel.add(new JLabel("Email:"), gbc);
        gbc.gridx = 1;
        quizPanel.add(emailField, gbc);

        gbc.gridy = 5;
        gbc.gridwidth = 2;
        quizPanel.add(new JScrollPane(questionArea), gbc);

        gbc.gridy = 6;
        gbc.gridwidth = 2;
        quizPanel.add(optionsPanel, gbc);

        gbc.gridy = 7;
        gbc.gridwidth = 1;
        quizPanel.add(nextButton, gbc);
        gbc.gridx = 1;
        quizPanel.add(submitQuizButton, gbc);

        gbc.gridy = 8;
        gbc.gridwidth = 2;
        quizPanel.add(new JLabel("Feedback:"), gbc);

        gbc.gridy = 9;
        gbc.gridwidth = 2;
        quizPanel.add(new JScrollPane(feedbackArea), gbc);

        submitQuizButton.addActionListener(this);
        nextButton.addActionListener(this);
    }

    private void loadQuestions() {
        questions = new ArrayList<>();
        String url = "jdbc:mysql://localhost:3306/quizdb";
        String user = "root";
        String password = "12345"; // Replace with your MySQL password

        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            String sql = "SELECT * FROM quizzes WHERE quiz_title = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, quizTitle);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                questions.add(new QuizQuestion(
                        rs.getString("question"),
                        rs.getString("option_a"),
                        rs.getString("option_b"),
                        rs.getString("option_c"),
                        rs.getString("option_d"),
                        rs.getString("correct_option")
                ));
            }

            if (!questions.isEmpty()) {
                displayQuestion();
            } else {
                JOptionPane.showMessageDialog(this, "No questions found for this quiz.", "Error", JOptionPane.ERROR_MESSAGE);
                cardLayout.show(mainPanel, "LinkPanel");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void displayQuestion() {
        if (currentQuestionIndex < questions.size()) {
            QuizQuestion currentQuestion = questions.get(currentQuestionIndex);
            questionArea.setText(currentQuestion.getQuestion());
            optionButtons[0].setText(currentQuestion.getOptionA());
            optionButtons[1].setText(currentQuestion.getOptionB());
            optionButtons[2].setText(currentQuestion.getOptionC());
            optionButtons[3].setText(currentQuestion.getOptionD());
            optionGroup.clearSelection();
        }
    }

    private void processAnswer() {
        QuizQuestion currentQuestion = questions.get(currentQuestionIndex);
        String selectedOption = null;
        for (int i = 0; i < 4; i++) {
            if (optionButtons[i].isSelected()) {
                selectedOption = optionButtons[i].getText();
                break;
            }
        }

        if (selectedOption == null) {
            JOptionPane.showMessageDialog(this, "Please select an option.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (selectedOption.equals(currentQuestion.getCorrectOption())) {
            score++;
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == submitLinkButton) {
            String quizLink = linkField.getText();
            if (quizLink.isEmpty()) {
                statusLabel.setText("Please enter a quiz link.");
                statusLabel.setForeground(Color.RED);
                return;
            }

            // Extract quiz title from the link
            quizTitle = quizLink.substring(quizLink.lastIndexOf('/') + 1).replace("_", " ").toUpperCase();

            // Load questions for the quiz
            loadQuestions();

            // Switch to the quiz panel
            cardLayout.show(mainPanel, "QuizPanel");
        } else if (e.getSource() == submitQuizButton) {
            processAnswer();
            saveScore();
            JOptionPane.showMessageDialog(this, "Quiz completed! Your score is: " + score, "Result", JOptionPane.INFORMATION_MESSAGE);
            enableFeedback();
        } else if (e.getSource() == nextButton) {
            processAnswer();
            currentQuestionIndex++;
            if (currentQuestionIndex < questions.size()) {
                displayQuestion();
            } else {
                JOptionPane.showMessageDialog(this, "You have reached the end of the quiz. Please submit your answers.", "Info", JOptionPane.INFORMATION_MESSAGE);
                nextButton.setEnabled(false);
            }
        }
    }

    private void saveScore() {
        String url = "jdbc:mysql://localhost:3306/User_Information";
        String user = "root";
        String password = "12345"; // Replace with your MySQL password

        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            String sql = "INSERT INTO user_scores (username, name, email, phone, score, quiz_title) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, usernameField.getText());
            stmt.setString(2, nameField.getText());
            stmt.setString(3, emailField.getText());
            stmt.setString(4, phoneField.getText());
            stmt.setInt(5, score);
            stmt.setString(6, quizTitle);

            stmt.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void enableFeedback() {
        feedbackArea.setEditable(true);
        submitQuizButton.setText("Submit Feedback");
    }

    // Inner class to hold quiz question data
    private static class QuizQuestion {
        private String question, optionA, optionB, optionC, optionD, correctOption;

        public QuizQuestion(String question, String optionA, String optionB, String optionC, String optionD, String correctOption) {
            this.question = question;
            this.optionA = optionA;
            this.optionB = optionB;
            this.optionC = optionC;
            this.optionD = optionD;
            this.correctOption = correctOption;
        }

        public String getQuestion() {
            return question;
        }

        public String getOptionA() {
            return optionA;
        }

        public String getOptionB() {
            return optionB;
        }

        public String getOptionC() {
            return optionC;
        }

        public String getOptionD() {
            return optionD;
        }

        public String getCorrectOption() {
            return correctOption;
        }
    }

    public static void main(String[] args) {
        new Display_quiz();
    }
}
