import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.border.BevelBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Operation extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Operation frame = new Operation();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Operation() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 874, 603);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("WELCOME BACK TO ONLINE");
		lblNewLabel_2.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setForeground(new Color(240, 255, 255));
		lblNewLabel_2.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 30));
		lblNewLabel_2.setBounds(10, 21, 479, 65);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("QUIZ GENERATOR");
		lblNewLabel_2_1.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_1.setForeground(new Color(240, 255, 255));
		lblNewLabel_2_1.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 30));
		lblNewLabel_2_1.setBounds(0, 75, 479, 65);
		contentPane.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_2_1_1 = new JLabel("VIJAY RICHHARIYA");
		lblNewLabel_2_1_1.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_2_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_1_1.setForeground(new Color(240, 255, 255));
		lblNewLabel_2_1_1.setFont(new Font("Serif", Font.ITALIC, 20));
		lblNewLabel_2_1_1.setBounds(10, 513, 479, 43);
		contentPane.add(lblNewLabel_2_1_1);
		
		JLabel lblNewLabel = new JLabel("VIJAY RICHHARIYA");
		lblNewLabel.setIcon(new ImageIcon("D:\\Quiz\\img\\stock-vector-quiz-speech-bubble-banner-with-quiz-text-glassmorphism-style-for-business-marketing-and-2018476604 (1).jpg"));
		lblNewLabel.setBounds(0, 0, 489, 566);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("GENERATE QUIZ");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Login_Admin obj = new Login_Admin();
				obj.setVisible(true);
			}
		});
		btnNewButton.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 18));
		btnNewButton.setHorizontalTextPosition(SwingConstants.CENTER);
		btnNewButton.setBounds(523, 186, 302, 48);
		contentPane.add(btnNewButton);
		
		JButton btnSolveQuiz = new JButton("SOLVE QUIZ ");
		btnSolveQuiz.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Display_quiz obj = new Display_quiz();
				obj.setVisible(true);
			}
		});
		btnSolveQuiz.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 18));
		btnSolveQuiz.setHorizontalTextPosition(SwingConstants.CENTER);
		btnSolveQuiz.setBounds(523, 281, 302, 48);
		contentPane.add(btnSolveQuiz);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setOpaque(true);
		lblNewLabel_1.setFocusTraversalPolicyProvider(true);
		lblNewLabel_1.setAutoscrolls(true);
		lblNewLabel_1.setBackground(new Color(0, 139, 139));
		lblNewLabel_1.setBounds(486, 0, 374, 566);
		contentPane.add(lblNewLabel_1);
	}
}
