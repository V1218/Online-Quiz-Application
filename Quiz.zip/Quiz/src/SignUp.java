import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

@SuppressWarnings("serial")
public class SignUp extends JFrame implements ActionListener {
    // Components
    private Container container;
    private JLabel userLabel;
    private JLabel passwordLabel;
    private JLabel confirmPasswordLabel;
    private JTextField userTextField;
    private JPasswordField passwordField;
    private JPasswordField confirmPasswordField;
    private JButton signUpButton;
    private JLabel statusLabel;

    // Constructor
    public SignUp() {
        setTitle("USER SIGN UP FORM");
        setBounds(300, 90, 400, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        container = getContentPane();
        container.setLayout(null);
        container.setBackground(new Color(60, 63, 65));

        // Username label
        userLabel = new JLabel("Username");
        userLabel.setForeground(Color.WHITE);
        userLabel.setFont(new Font("Arial", Font.BOLD, 14));
        userLabel.setBounds(49, 65, 281, 30);
        container.add(userLabel);

        // Password label
        passwordLabel = new JLabel("Password");
        passwordLabel.setForeground(Color.WHITE);
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 14));
        passwordLabel.setBounds(49, 115, 281, 30);
        container.add(passwordLabel);

        // Confirm Password label
        confirmPasswordLabel = new JLabel("Confirm Password");
        confirmPasswordLabel.setForeground(Color.WHITE);
        confirmPasswordLabel.setFont(new Font("Arial", Font.BOLD, 14));
        confirmPasswordLabel.setBounds(49, 165, 281, 30);
        container.add(confirmPasswordLabel);

        // Username text field
        userTextField = new JTextField();
        userTextField.setBounds(199, 65, 181, 30);
        userTextField.setBackground(new Color(169, 169, 169));
        userTextField.setForeground(Color.BLACK);
        userTextField.setFont(new Font("Arial", Font.PLAIN, 14));
        container.add(userTextField);

        // Password field
        passwordField = new JPasswordField();
        passwordField.setBounds(199, 115, 181, 30);
        passwordField.setBackground(new Color(169, 169, 169));
        passwordField.setForeground(Color.BLACK);
        passwordField.setFont(new Font("Arial", Font.PLAIN, 14));
        container.add(passwordField);

        // Confirm Password field
        confirmPasswordField = new JPasswordField();
        confirmPasswordField.setBounds(199, 165, 181, 30);
        confirmPasswordField.setBackground(new Color(169, 169, 169));
        confirmPasswordField.setForeground(Color.BLACK);
        confirmPasswordField.setFont(new Font("Arial", Font.PLAIN, 14));
        container.add(confirmPasswordField);

        // Sign Up button
        signUpButton = new JButton("Sign Up");
        signUpButton.setBounds(140, 225, 142, 41);
        signUpButton.setBackground(new Color(34, 139, 34));
        signUpButton.setForeground(Color.WHITE);
        signUpButton.setFont(new Font("Arial", Font.BOLD, 14));
        signUpButton.addActionListener(this);
        container.add(signUpButton);

        // Status label
        statusLabel = new JLabel("");
        statusLabel.setBounds(50, 300, 300, 30);
        statusLabel.setForeground(Color.RED);
        container.add(statusLabel);

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        setVisible(true);
    }

    // Action performed method
    @Override
    public void actionPerformed(ActionEvent e) {
        String username = userTextField.getText();
        String password = new String(passwordField.getPassword());
        String confirmPassword = new String(confirmPasswordField.getPassword());

        if (!password.equals(confirmPassword)) {
            statusLabel.setText("Passwords do not match");
            statusLabel.setForeground(Color.RED);
        } else if (username.isEmpty() || password.isEmpty()) {
            statusLabel.setText("Username and Password cannot be empty");
            statusLabel.setForeground(Color.RED);
        } else if (createUser(username, password)) {
            statusLabel.setText("User created successfully");
            statusLabel.setForeground(Color.GREEN);
            SignUp obj = new SignUp();
            obj.setVisible(false);
            Login_Admin obj1 = new Login_Admin();
            obj1.setVisible(true);
        } else {
            statusLabel.setText("User creation failed");
            statusLabel.setForeground(Color.RED);
        }
    }

    // Method to create a new user
    private boolean createUser(String username, String password) {
        boolean isUserCreated = false;
        String url = "jdbc:mysql://localhost:3306/admindb";
        String dbUsername = "root"; // Replace with your DB username
        String dbPassword = "12345"; // Replace with your DB password

        try {
            Connection con = DriverManager.getConnection(url, dbUsername, dbPassword);
            String sql = "INSERT INTO adminid (username, password) VALUES (?, ?)";
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setString(1, username);
            statement.setString(2, password);

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                isUserCreated = true;
            }

            statement.close();
            con.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return isUserCreated;
    }

    // Main method for testing
    public static void main(String[] args) {
        new SignUp();
    }
}
